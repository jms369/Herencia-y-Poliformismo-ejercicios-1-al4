package ejer_4_3;

public class Main {
    public static void main(String[] args) {

        Tableta obj = new Tableta("Dell");

    }
}
