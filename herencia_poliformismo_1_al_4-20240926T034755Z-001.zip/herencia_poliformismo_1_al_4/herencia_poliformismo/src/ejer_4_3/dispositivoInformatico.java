package ejer_4_3;

public class dispositivoInformatico {
    String marca= "Acer";

    dispositivoInformatico(){
        System.out.println("marca: "+marca);
    }
}
