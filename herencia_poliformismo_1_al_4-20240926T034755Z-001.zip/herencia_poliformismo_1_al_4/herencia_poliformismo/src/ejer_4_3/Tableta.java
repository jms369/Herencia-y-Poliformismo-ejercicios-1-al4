package ejer_4_3;

public class Tableta extends dispositivoInformatico{

    Tableta(String marca){
        System.out.println("marca: "+marca);
    }
}
