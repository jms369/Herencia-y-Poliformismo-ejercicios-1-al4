package ejer_4_1_propuesto;

public class NOVELAS extends LIBRO{
    public enum Categoria{HISTÓRICA, ROMÁNTICA, POLICIACA, REALISTA,CIENCIA_FICCIÓN, AVENTURAS} Categoria tipoNovela;

    public NOVELAS(String titulo, String autor, double precio, Categoria tipoNovela){
        super(titulo, autor, precio);
        this.tipoNovela = tipoNovela;

    }

    public Categoria getTipoNovela() {
        return tipoNovela;
    }

    public void setTipoNovela(Categoria tipoNovela) {
        this.tipoNovela = tipoNovela;
    }

    public void ImprimirNovela(){
        System.out.println("Titulo de la novela: "+getTitulo());
        System.out.println("Autor: "+getAutor());
        System.out.println("Precio: "+getPrecio());
        System.out.println("tipo de novela: "+getTipoNovela());
        System.out.println("-------------------------------------------------------------");

    }
}
