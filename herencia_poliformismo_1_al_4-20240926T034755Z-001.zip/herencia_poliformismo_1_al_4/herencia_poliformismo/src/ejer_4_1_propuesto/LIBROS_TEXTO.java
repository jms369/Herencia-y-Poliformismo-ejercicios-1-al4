package ejer_4_1_propuesto;

public class LIBROS_TEXTO extends LIBRO{
    public String curso;

    public LIBROS_TEXTO(String titulo, String autor,double precio,String curso){
        super(titulo, autor, precio);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }
    public void ImprimirLibrosTextos(){
        System.out.println("Titulo del libro: "+getTitulo());
        System.out.println("Autor: "+getAutor());
        System.out.println("curso: "+getCurso());
        System.out.println("Precio: "+getPrecio());
        System.out.println("-------------------------------------------------------------");
    }

}
