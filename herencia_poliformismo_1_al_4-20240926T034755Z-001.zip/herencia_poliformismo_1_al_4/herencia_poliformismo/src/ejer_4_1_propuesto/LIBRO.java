package ejer_4_1_propuesto;

public class LIBRO {
    public String titulo, autor;
    public double precio;

    public LIBRO(String titulo, String autor, double precio){
        this.titulo = titulo;
        this.autor = autor;
        this.precio = precio;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void ImprimirLibro(){
        System.out.println("Titulo del libro: "+getTitulo());
        System.out.println("Autor: "+getAutor());
        System.out.println("Precio: "+getPrecio());
        System.out.println("-------------------------------------------------------------");
    }
}
