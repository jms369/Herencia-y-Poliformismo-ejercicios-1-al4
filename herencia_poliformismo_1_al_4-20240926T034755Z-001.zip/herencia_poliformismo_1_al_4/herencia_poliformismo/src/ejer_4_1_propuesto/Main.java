package ejer_4_1_propuesto;

public class Main { public static void main(String[] args) {

    LIBRO Obj = new LIBRO("La fusca","Le Suegre",100);
    Obj.ImprimirLibro();

    LIBROS_TEXTO Obj2 = new LIBROS_TEXTO("la mos","Mekito",500,"");
    Obj2.setCurso("3ro sec.");
    Obj2.ImprimirLibrosTextos();

    LIBROS_UNI_N_C Obj3 = new LIBROS_UNI_N_C("El pen", "Yoka simeca go ", 1000,"Derecho");
    Obj3.ImprimirUniversidad();

    NOVELAS Obj4 = new NOVELAS("tela com","Homerosagua",250, NOVELAS.Categoria.AVENTURAS);
    Obj4.ImprimirNovela();
}
}
