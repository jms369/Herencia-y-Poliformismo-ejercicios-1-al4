package ejer_4_1_propuesto;

public class LIBROS_UNI_N_C extends LIBRO{
    public String facultad;

    public LIBROS_UNI_N_C(String titulo,String autor,double precio,String facultad){
        super(titulo,autor,precio);
        this.facultad = facultad;
    }

    public String getFacultad() {
        return facultad;
    }

    public void setFacultad(String facultad) {
        this.facultad = facultad;
    }

    public void ImprimirUniversidad(){
        System.out.println("Titulo del libro: "+getTitulo());
        System.out.println("Autor: "+getAutor());
        System.out.println("Precio: "+getPrecio());
        System.out.println("Facultad: "+getFacultad());
        System.out.println("-------------------------------------------------------------");
    }
}
