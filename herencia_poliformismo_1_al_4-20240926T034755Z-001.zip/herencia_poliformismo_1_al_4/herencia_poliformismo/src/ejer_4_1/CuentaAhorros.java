package ejer_4_1;

public class CuentaAhorros extends CUENTA{
    private boolean activa;

    public CuentaAhorros(float saldo, float tasa){
        super(saldo,tasa);
        if (saldo<10000){
            activa = false;
        }
        else{
            activa = true;
        }
    }
    public void Retirar(float cantidad){
        if(activa== true){
            super.Retirar(cantidad);
        }
    }

    public void Consignar( float cantidad){
        if(activa==true){
            super.Consignar(cantidad);
        }
    }

    public void ExtractoMensual(){
        if(numeroRetiros>4){
            comisionMensual = comisionMensual+((numeroRetiros-4)*1000);
        }
        super.ExtractoMensual();
        if (saldo<10000){
            activa = false;
        }
    }

    public void Imprimir(){
        System.out.println("saldo =$ "+saldo);
        System.out.println("comision mensual= $ "+comisionMensual);
        System.out.println("numero de transacciones = "+numeroRetiros+numeroConsignaciones);
        System.out.println(" ");
    }
}

