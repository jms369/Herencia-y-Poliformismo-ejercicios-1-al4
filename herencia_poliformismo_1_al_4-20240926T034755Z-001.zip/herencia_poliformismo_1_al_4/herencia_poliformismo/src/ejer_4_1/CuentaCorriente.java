package ejer_4_1;

public class CuentaCorriente extends CUENTA{

    float sobregiro;

    public CuentaCorriente(float saldo, float tasa){
        super(saldo,tasa);
        sobregiro = 0;
    }

    public void Retirar(float cantidad){
        float resultado = saldo-cantidad;

        if(resultado<0){
            sobregiro = sobregiro-resultado;
            saldo = 0;
        }
        else{
            super.Retirar(cantidad);
        }
    }
    public void Consignar(float cantidad){

        float residuo = sobregiro -cantidad;
        if (sobregiro > 0) {

            if(residuo>0){
                sobregiro = 0;
                saldo = residuo;
            }
            else{
                sobregiro = sobregiro-residuo;
                saldo = 0;
            }
            }
        else{
            super.Consignar(cantidad);
        }
    }
    public void ExtractoMensual(){
        super.ExtractoMensual();
    }
    public void Imprimir(){
        System.out.println("Saldo = $" + saldo);
        System.out.println("Cargo mensual = $ " + comisionMensual);
        System.out.println("Número de transacciones = " + (numeroConsignaciones + numeroRetiros));
        System.out.println("Valor de sogregiro = $"+ (numeroConsignaciones + numeroRetiros));
        System.out.println();
    }
}
