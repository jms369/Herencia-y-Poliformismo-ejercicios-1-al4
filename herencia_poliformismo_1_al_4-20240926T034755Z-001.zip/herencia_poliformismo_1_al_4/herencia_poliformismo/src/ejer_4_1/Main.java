package ejer_4_1;

import java.util.Scanner;


public class Main { public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Cuenta de ahorros");

        System.out.println("ingrese el saldo inicial $=");
        float saldoInicialAhorros = input.nextFloat();

        System.out.println("ingrese la tasa de interes= ");
        float tasaAhorros = input.nextFloat();

        CuentaAhorros Cuenta1 = new CuentaAhorros(saldoInicialAhorros,tasaAhorros);
        System.out.print("Ingresar cantidad a consignar: $");
        float cantidadDepositar = input.nextFloat();
        Cuenta1.Consignar(cantidadDepositar);
        System.out.print("Ingresar cantidad a retirar: $");
        float cantidadRetirar = input.nextFloat();
        Cuenta1.Retirar(cantidadRetirar);
        Cuenta1.ExtractoMensual();
        Cuenta1.Imprimir();
    }
}