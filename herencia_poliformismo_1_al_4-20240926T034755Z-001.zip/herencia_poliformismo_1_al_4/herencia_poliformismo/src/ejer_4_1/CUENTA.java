package ejer_4_1;

public class CUENTA {
    protected float saldo, tasaAnual, comisionMensual=0;
    protected int numeroConsignaciones=0, numeroRetiros=0;

    public CUENTA(float saldo, float tasaAnual){
        this.saldo = saldo;
        this.tasaAnual = tasaAnual;
    }
    public void Consignar(float cantidad){
        saldo = saldo+cantidad;
        numeroConsignaciones = numeroConsignaciones +1;
    }
    public void Retirar(float cantidad){
        float nuevoSaldo = saldo-cantidad;

        if(nuevoSaldo>=0){
            saldo= saldo-cantidad;
            numeroRetiros = numeroRetiros +1;
        }
        else{
            System.out.println("La cantidad a retirar excede el saldo actual");
        }

    }
    public void CalculaInteres(){
        float tasaMensual = tasaAnual/12;
        float interesMensual = (saldo/100)*tasaMensual;
        saldo = saldo+interesMensual;
    }
    public void ExtractoMensual(){
        saldo = saldo-comisionMensual;
        CalculaInteres();
    }

}
