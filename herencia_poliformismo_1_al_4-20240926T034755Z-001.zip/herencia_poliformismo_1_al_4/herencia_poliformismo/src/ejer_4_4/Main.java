package ejer_4_4;

public class Main {
    public static void main(String[] args) {

        PROFESOR obj1 = new ProfesorTitular();
        obj1.Imprimir();
    }
}
