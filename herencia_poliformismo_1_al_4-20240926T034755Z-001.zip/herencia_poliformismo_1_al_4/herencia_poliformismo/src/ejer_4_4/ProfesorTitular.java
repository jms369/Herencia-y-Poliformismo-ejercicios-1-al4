package ejer_4_4;

public class ProfesorTitular extends PROFESOR{

    protected void Imprimir(){
        System.out.println("Es un profesor titular");
    }
}
