package ejer_4_4;

public class PROFESOR {

    protected void Imprimir(){
        System.out.println("Es un profesor");
    }
}
