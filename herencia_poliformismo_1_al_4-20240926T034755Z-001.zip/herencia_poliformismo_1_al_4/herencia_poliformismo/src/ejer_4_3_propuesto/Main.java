package ejer_4_3_propuesto;

public class Main {
    public static void main(String[] args) {

        ESTUDIANTE obj1 = new ESTUDIANTE("elver","quiensa 12","economia",3);

        PROFESOR obj2 = new PROFESOR("elma", "noesde 33","cba","b");
    }
}
