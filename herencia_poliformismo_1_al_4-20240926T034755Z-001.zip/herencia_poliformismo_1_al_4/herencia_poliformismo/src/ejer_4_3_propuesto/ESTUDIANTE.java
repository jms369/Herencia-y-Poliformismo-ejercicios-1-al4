package ejer_4_3_propuesto;

public class ESTUDIANTE extends PERSONA{

    protected String carrera;
    protected int semestre;

    public ESTUDIANTE(String nombre,String direccion, String carrera, int semestre){
        super(nombre, direccion);
        this.carrera = carrera;
        this.semestre = semestre;

        System.out.println("--------------ESTUDIANTE-------------");
        System.out.println("nombre: "+getNombre());
        System.out.println("dirección: "+getDireccion());
        System.out.println("carrera: "+getCarrera());
        System.out.println("semestre: "+getSemestre());
        System.out.println(" ");
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }
}
