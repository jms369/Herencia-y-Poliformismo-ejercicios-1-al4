package ejer_4_2_propuesto;

public class Main {
    public static void main(String[] args) {


        PERROS_PEQUENYOS obj1 = new PERROS_PEQUENYOS("max","marron",3,5,true,PERROS_PEQUENYOS.tiporaza.CHIHUAHUA);
        obj1.ImprimirPerrosPequenyo();


        GATOS_SIN_PELO obj4 = new GATOS_SIN_PELO("bigotes","gris",2,1.70,3.1,GATOS_SIN_PELO.tiporaza.ELFO);
        obj4.ImprimirGatosSinPelo();
    }
}
