package ejer_4_2_propuesto;

public class MASCOTA {
    public String nombre, color;
    public int edad;

    public MASCOTA(String nombre, int edad, String color){
        this.nombre = nombre;
        this.edad = edad;
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public String getColor() {
        return color;
    }

    public int getEdad() {
        return edad;
    }
}
