package ejer_4_2_propuesto;

public class PERROS_GRANDES extends PERROS{

    enum tiporaza{PASTOR_ALEMÁN, DOBERMAN, ROTWEILLER}
    public tiporaza tipoRaza;

    public PERROS_GRANDES(String nombre, String color, int edad, double peso, boolean muerde, tiporaza tipoRaza){
        super(nombre, color, edad, peso, muerde);
        this.tipoRaza = tipoRaza;
    }

    public tiporaza getTipoRaza() {
        return tipoRaza;
    }

    public void ImprimirPerroGrandes(){
        System.out.println("-----------PERRO GRANDE-----------");
        System.out.println("nombre: "+getNombre());
        System.out.println("edad: "+getEdad()+" años");
        System.out.println("color: "+getColor());
        System.out.println("peso: "+getPeso()+" kg");
        if(isMuerde()==true){
            System.out.println("el perro muerde?: si");
        }
        else{
            System.out.println("el perro muerde?: no");
        }
        System.out.println("tipo de raza: "+getTipoRaza());
        PERROS.Sonido();
        System.out.println(" ");
    }
}
