package ejer_4_2_propuesto;

import java.sql.SQLOutput;

public class GATOS extends MASCOTA{

    public double altura_salto, longitud_salto;

    public GATOS(String nombre, String color, int edad,double altura_salto, double longitud_salto){
        super(nombre, edad, color);
        this.altura_salto = altura_salto;
        this.longitud_salto = longitud_salto;
    }

    public double getAltura_salto() {
        return altura_salto;
    }

    public double getLongitud_salto() {
        return longitud_salto;
    }
    public static void Sonido(){

        System.out.println("Los gatos maúllan y ronronean");
    }
}
