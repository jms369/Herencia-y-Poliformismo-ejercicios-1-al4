package ejer_4_2_propuesto;

public class GATOS_PELO_CORTO extends GATOS{

    enum tiporaza{AZUL_RUSO, BRITÁNICO, MANX, DEVON_REX}
    public tiporaza tipoRaza;

    public GATOS_PELO_CORTO(String nombre, String color, int edad,double altura_salto, double longitud_salto, tiporaza tipoRaza){
        super(nombre, color, edad, altura_salto, longitud_salto);
        this.tipoRaza = tipoRaza;
    }

    public tiporaza getTipoRaza() {
        return tipoRaza;
    }
    public void ImprimirGatosPeloCorto(){
        System.out.println("------GATO DE PELO CORTO----------");
        System.out.println("nombre: "+getNombre());
        System.out.println("edad: "+getEdad()+" años");
        System.out.println("color: "+getColor());
        System.out.println("altura de salto: "+getAltura_salto()+" metros");
        System.out.println("longitud de salto: "+getLongitud_salto()+" metros");
        System.out.println("tipo de raza: "+getTipoRaza());
        GATOS.Sonido();
        System.out.println(" ");
    }
}
