package ejer_4_2_propuesto;

public class GATOS_SIN_PELO extends GATOS{

    enum tiporaza{ESFINGE, ELFO, DONSKOY}
    public tiporaza tipoRaza;

    public GATOS_SIN_PELO(String nombre, String color, int edad,double altura_salto, double longitud_salto, tiporaza tipoRaza){
        super(nombre, color, edad, altura_salto, longitud_salto);
        this.tipoRaza = tipoRaza;
    }

    public tiporaza getTipoRaza() {
        return tipoRaza;
    }
    public void ImprimirGatosSinPelo(){
        System.out.println("------GATO SIN PELO----------");
        System.out.println("nombre: "+getNombre());
        System.out.println("edad: "+getEdad()+" años");
        System.out.println("color: "+getColor());
        System.out.println("altura de salto: "+getAltura_salto()+" metros");
        System.out.println("longitud de salto: "+getLongitud_salto()+" metros");
        System.out.println("tipo de raza: "+getTipoRaza());
        GATOS.Sonido();
        System.out.println(" ");
    }
}
