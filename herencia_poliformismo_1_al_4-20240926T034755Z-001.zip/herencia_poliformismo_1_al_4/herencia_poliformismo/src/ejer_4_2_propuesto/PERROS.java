package ejer_4_2_propuesto;

public class PERROS extends MASCOTA{

    public double peso;
    public boolean muerde;

    public PERROS(String nombre, String color, int edad, double peso, boolean muerde){
        super(nombre, edad, color);
        this.peso = peso;
        this.muerde = muerde;
    }

    public static void Sonido(){
        System.out.println("Los perros ladran");
    }

    public double getPeso() {
        return peso;
    }

    public boolean isMuerde() {

        return muerde;
    }
}
