package ejer_4_4_propuesto;

public class ProfesorTitular extends PROFESOR {

    protected void Imprimir(){
        System.out.println("Es un profesor titular");
    }
}
