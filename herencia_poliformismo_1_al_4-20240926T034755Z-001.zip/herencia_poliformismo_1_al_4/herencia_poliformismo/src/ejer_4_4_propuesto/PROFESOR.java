package ejer_4_4_propuesto;

public class PROFESOR {

    protected void Imprimir(){
        System.out.println("Es un profesor");
    }
}
