package ejer_4_4_propuesto;

public class Main {
    public static void main(String[] args) {

        PROFESOR obj1 = new ProfesorTitular();
        PROFESOR obj2 = (PROFESOR) obj1;
        obj2.Imprimir();
    }
}
